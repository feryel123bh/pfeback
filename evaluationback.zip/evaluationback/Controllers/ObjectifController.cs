using Microsoft.AspNetCore.Mvc;
using evaluationback.Models.Domain;
using evaluationback.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using evaluationback.Models.DTO;

namespace evaluationback.Controllers
{
  [ApiController]
  [Route("api/objectives")]
  public class ObjectivesController : ControllerBase
  {
    private readonly ObjectifService _objectifService;

    public ObjectivesController(ObjectifService objectifService)
    {
      _objectifService = objectifService;
    }

    [HttpGet("{employeeId}/{year}")]
    public async Task<ActionResult<List<Objectif>>> GetObjectivesByEmployee(Guid employeeId, int year)
    {
      var objectives = await _objectifService.GetObjectifsByEmployeeAsync(employeeId);

      objectives = objectives.FindAll(o => o.DateDebut.Year <= year && o.DateFin.Year >= year);

      if (objectives == null || objectives.Count == 0)
      {
        return NotFound();
      }

      return Ok(objectives);
    }

    [HttpPost]
    public async Task<ActionResult<Objectif>> CreateObjective(Objectif objectif)
    {
      var createdObjective = await _objectifService.CreateObjectifAsync(objectif);
      return CreatedAtAction(nameof(GetObjectivesByEmployee), new { employeeId = objectif.EmployeeId, year = DateTime.Now.Year }, createdObjective);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateObjectiveStatus(Guid id, [FromBody] string status)
    {
      await _objectifService.UpdateObjectiveStatus(id, status);
      return NoContent();
    }

    [HttpPut("progress/{id}")]
    public async Task<IActionResult> UpdateObjectiveProgress(Guid id, [FromBody] int progress)
    {
      await _objectifService.UpdateObjectiveProgress(id, progress);
      return NoContent();
    }

    [HttpPost("{id}/note")]
    public async Task<IActionResult> NoterObjectif(Guid id, [FromBody] ObjectifRatingDto ratingDto)
    {
      await _objectifService.NoterObjectifAsync(id, ratingDto.Note, ratingDto.Commentaire);
      return NoContent();
    }
  }
}
