using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using evaluationback.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Controllers
{
  [ApiController]
  [Route("api/formulaire")]
  public class FormulaireController : ControllerBase
  {
    private readonly IFormulaireService _formulaireService;

    public FormulaireController(IFormulaireService formulaireService)
    {
      _formulaireService = formulaireService;
    }

    [HttpPost]
    public async Task<ActionResult<Guid>> CreateFormulaire([FromBody] FormulaireDto formulaireDto)
    {
      if (formulaireDto == null)
      {
        return BadRequest("Invalid form data.");
      }

      try
      {
        var formulaireId = await _formulaireService.SaveFormulaireAsync(formulaireDto);
        return Ok(formulaireId);
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Formulaire>> GetFormulaireById(Guid id)
    {
      try
      {
        var formulaire = await _formulaireService.GetFormulaireByIdAsync(id);
        if (formulaire == null)
        {
          return NotFound($"Form with ID {id} not found.");
        }
        return Ok(formulaire);
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }

    [HttpGet]
    public async Task<ActionResult<List<Formulaire>>> GetAllFormulaires()
    {
      try
      {
        var formulaires = await _formulaireService.GetAllFormulairesAsync();
        return Ok(formulaires);
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteFormulaire(Guid id)
    {
      try
      {
        await _formulaireService.DeleteFormulaireAsync(id);
        return NoContent();
      }
      catch (KeyNotFoundException)
      {
        return NotFound($"Form with ID {id} not found.");
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateFormulaire(Guid id, [FromBody] FormulaireDto formulaireDto)
    {
      if (id == Guid.Empty || formulaireDto == null)
      {
        return BadRequest("Invalid form data.");
      }

      try
      {
        await _formulaireService.UpdateFormulaireAsync(id, formulaireDto);
        return NoContent();
      }
      catch (KeyNotFoundException)
      {
        return NotFound($"Form with ID {id} not found.");
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }
  }
}
