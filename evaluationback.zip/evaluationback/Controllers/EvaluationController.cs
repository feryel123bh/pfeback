using evaluationback.Models.Domain;
using evaluationback.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

[Route("api/evaluations")]
[ApiController]
public class EvaluationController : ControllerBase
{
  private readonly IEvaluationService _evaluationService;

  public EvaluationController(IEvaluationService evaluationService)
  {
    _evaluationService = evaluationService;
  }

  [HttpGet]
  public async Task<ActionResult<IEnumerable<Evaluation>>> GetAllEvaluations()
  {
    var evaluations = await _evaluationService.GetAllEvaluationsAsync();
    return Ok(evaluations);
  }

  [HttpGet("{id}")]
  public async Task<ActionResult<Evaluation>> GetEvaluation(Guid id)
  {
    var evaluation = await _evaluationService.GetEvaluationByIdAsync(id);
    if (evaluation == null)
    {
      return NotFound($"Evaluation with ID {id} not found.");
    }
    return Ok(evaluation);
  }

  [HttpPost]
  public async Task<ActionResult<Evaluation>> CreateEvaluation([FromBody] Evaluation evaluation)
  {
    if (evaluation == null)
    {
      return BadRequest("Invalid evaluation data.");
    }

    var createdEvaluation = await _evaluationService.CreateEvaluationAsync(evaluation);
    return CreatedAtAction(nameof(GetEvaluation), new { id = createdEvaluation.Id }, createdEvaluation);
  }

  [HttpPut("{id}")]
  public async Task<IActionResult> UpdateEvaluation(Guid id, [FromBody] Evaluation evaluation)
  {
    if (evaluation == null || id != evaluation.Id)
    {
      return BadRequest("Invalid evaluation data or ID mismatch.");
    }

    try
    {
      await _evaluationService.UpdateEvaluationAsync(evaluation);
      return NoContent();
    }
    catch (ArgumentException)
    {
      return NotFound($"Evaluation with ID {id} not found.");
    }
  }

  [HttpDelete("{id}")]
  public async Task<IActionResult> DeleteEvaluation(Guid id)
  {
    try
    {
      await _evaluationService.DeleteEvaluationAsync(id);
      return NoContent();
    }
    catch (ArgumentException)
    {
      return NotFound($"Evaluation with ID {id} not found.");
    }
  }
}
