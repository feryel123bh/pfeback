using evaluationback.Models.Domain;
using evaluationback.Services;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;

namespace evaluationback.Controllers
{
  [ApiController]
  [Route("api/employe")]
  public class EmployeeController : ControllerBase
  {
    private readonly IEmployeeService _employeeService;
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(IEmployeeService employeeService, ILogger<EmployeeController> logger)
    {
      _employeeService = employeeService;
      _logger = logger;
    }
    [HttpGet("getallemployees")]
    [ProducesResponseType(typeof(IEnumerable<Employee>), 200)]
    public async Task<IActionResult> GetAllEmployeesSimple()
    {
      try
      {
        // Get employees with the role 'EmployeSimple'
        var employees = await _employeeService.GetEmployeesByRoleAsync(Role.EmployeSimple);
        return Ok(employees);
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Error fetching employees.");
        return BadRequest("An error occurred while fetching employees.");
      }
    }


    [HttpGet("getall")]
    [ProducesResponseType(typeof(IEnumerable<Employee>), 200)]
    public async Task<IActionResult> GetAllEmployees()
    {
      try
      {
        var employees = await _employeeService.GetAllEmployeesAsync();
        return Ok(employees);
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Error fetching employees.");
        return BadRequest("An error occurred while fetching employees.");
      }
    }

    [HttpGet("getmanager")]
    [ProducesResponseType(typeof(IEnumerable<Employee>), 200)]
    [ProducesResponseType(400)]
    public async Task<IActionResult> GetAllManagers()
    {
      try
      {
        var managers = await _employeeService.GetAllManagersAsync();
        return Ok(managers);
      }
      catch (Exception ex)
      {
        _logger.LogError(ex, "Error fetching managers.");
        return BadRequest("An error occurred while fetching managers.");
      }
    }

    [HttpGet("{id}")]
    [ProducesResponseType(typeof(Employee), 200)]
    public async Task<IActionResult> GetEmployeeByIdAsync(Guid id)
    {
      var employee = await _employeeService.GetEmployeeById(id);
      if (employee == null)
      {
        return NotFound();
      }
      return Ok(employee);
    }

    [HttpPost]
    [Authorize(Roles = "Rh")]
    public async Task<ActionResult<Employee>> AddEmployee([FromBody] Employee employee)
    {
      var addedEmployee = await _employeeService.AddEmployee(employee);
      return CreatedAtAction(nameof(GetEmployeeByIdAsync), new { id = addedEmployee.Id }, addedEmployee);
    }

    [HttpPut("{id}")]
    [ProducesResponseType(typeof(Employee), 200)]
    public async Task<IActionResult> UpdateEmployee(Guid id, [FromBody] Employee updatedEmployee)
    {
      try
      {
        var employee = await _employeeService.UpdateEmployee(id, updatedEmployee);
        return Ok(employee);
      }
      catch (ArgumentException)
      {
        return NotFound();
      }
    }

    [HttpDelete("{id}")]
    [ProducesResponseType(204)]
    public async Task<IActionResult> DeleteEmployee(Guid id)
    {
      try
      {
        await _employeeService.DeleteEmployee(id);
        return NoContent();
      }
      catch (ArgumentException)
      {
        return NotFound();
      }
    }

    [HttpGet("export")]
    public IActionResult ExportEmployeesToExcel()
    {
      var content = _employeeService.ExportEmployeesToExcel();
      var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      var fileName = "Employees.xlsx";

      return File(content, contentType, fileName);
    }

    [HttpPost("import")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> ImportEmployees(IFormFile file)
    {
      try
      {
        if (file == null || file.Length == 0)
        {
          return BadRequest("Fichier non fourni");
        }

        if (!file.FileName.EndsWith(".xlsx"))
        {
          return BadRequest("Le fichier doit être au format Excel (.xlsx)");
        }

        byte[] fileBytes;
        using (var memoryStream = new MemoryStream())
        {
          await file.CopyToAsync(memoryStream);
          fileBytes = memoryStream.ToArray();
        }

        _employeeService.ImportEmployeesFromExcel(fileBytes);
        return Ok("Les employés ont été importés avec succès.");
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Une erreur s'est produite lors de l'importation des employés : {ex.Message}");
      }
    }
  }
}
