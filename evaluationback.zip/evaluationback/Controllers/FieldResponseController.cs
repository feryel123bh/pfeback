using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using evaluationback.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Controllers
{
  [ApiController]
  [Route("api/FieldResponse")]
  public class FieldResponseController : ControllerBase
  {
    private readonly IFieldResponseService _fieldResponseService;

    public FieldResponseController(IFieldResponseService fieldResponseService)
    {
      _fieldResponseService = fieldResponseService;
    }

    // POST api/fieldresponse
    [HttpPost]
    public async Task<IActionResult> SubmitFieldResponse([FromBody] FieldResponseSubmissionDto submission)
    {
      if (submission.FieldResponses == null || submission.FieldResponses.Count == 0)
      {
        return BadRequest("Field responses cannot be null or empty.");
      }

      try
      {
        var result = await _fieldResponseService.SubmitFormResponsesAsync(submission.FieldResponses, submission.EmployeeId);

        if (result)
        {
          return Ok(new { message = "Form responses submitted successfully." });
        }
        else
        {
          return StatusCode(500, "There was an issue submitting the form responses.");
        }
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }

    // GET api/fieldresponse/form/{formulaireId}/employee/{employeeId}
    [HttpGet("form/{formulaireId}/employee/{employeeId}")]
    public async Task<IActionResult> GetFormResponsesByEmployee(Guid formulaireId, Guid employeeId)
    {
      try
      {
        var responses = await _fieldResponseService.GetFormResponsesByEmployeeAsync(employeeId, formulaireId);
        if (responses == null || responses.Count == 0)
        {
          return NotFound("No responses found for this employee and form.");
        }

        return Ok(responses);
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }
  }
}
