using evaluationback.Models.Domain;
using evaluationback.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using evaluationback.Models.DTO;

[Route("api/campagne")]
[ApiController]
public class CampagneController : ControllerBase
{
  private readonly ICampagneService _campagneService;
  private readonly ICampaignreportService _campaignreportService;

  public CampagneController(ICampagneService campagneService, ICampaignreportService campaignreportService)
  {
    _campagneService = campagneService;
    _campaignreportService = campaignreportService;
  }

  [HttpPost]
  public async Task<ActionResult<Campagne>> CreateCampagne([FromBody] CreateCampagneRequest request)
  {
    if (request == null || request.Campagne == null || request.ManagerId == Guid.Empty)
    {
      return BadRequest("Invalid campaign data. Please ensure all fields are provided.");
    }

    try
    {
      var createdCampagne = await _campagneService.CreateCampagneAsync(
          request.Campagne,
          request.ManagerId,
          request.FormulaireId);

      // Initialize the CampaignReport after the campaign is created
      var campaignReport = new CampaignReport
      {
        CampagneId = createdCampagne.Id,
        Titre = createdCampagne.Titre,
        DateDebut = createdCampagne.StartDate,
        DateFin = createdCampagne.EndDate,
        TotalEmployees = createdCampagne.Equipes.Sum(e => e.Employees.Count),
        CompletedEvaluations = 0,
        PendingEvaluations = createdCampagne.Equipes.Sum(e => e.Employees.Count),
        AverageScore = 0,
        Comments = new List<string>()
      };

      await _campaignreportService.CreateCampaignReportAsync(campaignReport);

      return CreatedAtAction(nameof(GetCampagne), new { id = createdCampagne.Id }, createdCampagne);
    }
    catch (Exception ex)
    {
      return StatusCode(500, $"Internal server error: {ex.Message}");
    }
  }

  [HttpGet]
  public async Task<ActionResult<List<Campagne>>> GetAllCampagne()
  {
    List<Campagne> campagnes = await _campagneService.GetAllCampagnesAsync();
    return Ok(campagnes);
  }

  [HttpGet("{id}")]
  public async Task<ActionResult<Campagne>> GetCampagne(Guid id)
  {
    var campagne = await _campagneService.GetCampagneByIdAsync(id);
    if (campagne == null)
    {
      return NotFound($"Campaign with ID {id} not found.");
    }
    return Ok(campagne);
  }

  [HttpGet("{id}/report")]
  public async Task<ActionResult<CampaignReport>> GetCampaignReport(Guid id)
  {
    var report = await _campaignreportService.GetCampaignReportByCampaignIdAsync(id);
    if (report == null)
    {
      return NotFound($"Report for Campaign with ID {id} not found.");
    }
    return Ok(report);
  }

  [HttpPut("{id}")]
  public async Task<IActionResult> UpdateCampagne(Guid id, [FromBody] Campagne campagne)
  {
    if (campagne == null || id != campagne.Id)
    {
      return BadRequest("Invalid campaign data or ID mismatch.");
    }

    try
    {
      await _campagneService.UpdateCampagneAsync(id, campagne);
      return NoContent();
    }
    catch (ArgumentException)
    {
      return NotFound($"Campaign with ID {id} not found.");
    }
    catch (Exception ex)
    {
      return StatusCode(500, $"Internal server error: {ex.Message}");
    }
  }

  [HttpPut("{id}/report")]
  public async Task<IActionResult> UpdateCampaignReport(Guid id, [FromBody] CampaignReport report)
  {
    if (report == null || id != report.CampagneId)
    {
      return BadRequest("Invalid report data or ID mismatch.");
    }

    try
    {
      await _campaignreportService.UpdateCampaignReportAsync(report);
      return NoContent();
    }
    catch (ArgumentException)
    {
      return NotFound($"Report for Campaign with ID {id} not found.");
    }
    catch (Exception ex)
    {
      return StatusCode(500, $"Internal server error: {ex.Message}");
    }
  }

  [HttpDelete("{id}")]
  public async Task<IActionResult> DeleteCampagne(Guid id)
  {
    try
    {
      await _campagneService.DeleteCampagneAsync(id);
      return NoContent();
    }
    catch (ArgumentException)
    {
      return NotFound($"Campaign with ID {id} not found.");
    }
    catch (Exception ex)
    {
      return StatusCode(500, $"Internal server error: {ex.Message}");
    }
  }
  [HttpPost("{id}/report")]
  public async Task<IActionResult> CreateCampaignReport(Guid id, [FromBody] CampaignReport report)
  {
    if (report == null || string.IsNullOrEmpty(report.Titre))
    {
      return BadRequest("Invalid report data.");
    }

    try
    {
      report.CampagneId = id;
      await _campaignreportService.CreateCampaignReportAsync(report);
      return NoContent();
    }
    catch (Exception ex)
    {
      return StatusCode(500, $"Internal server error: {ex.Message}");
    }
  }


  [HttpPost("{id}/launch")]
  public async Task<IActionResult> LaunchCampagne(Guid id)
  {
    try
    {
      await _campagneService.LaunchCampaignAsync(id);

      // Update the CampaignReport after the campaign is launched
      var report = await _campaignreportService.GetCampaignReportByCampaignIdAsync(id);
      if (report != null)
      {
        report.DateDebut = DateTime.UtcNow;
        await _campaignreportService.UpdateCampaignReportAsync(report);
      }

      return NoContent();
    }
    catch (ArgumentException)
    {
      return NotFound($"Campaign with ID {id} not found.");
    }
    catch (InvalidOperationException)
    {
      return BadRequest("The campaign has already been launched.");
    }
    catch (Exception ex)
    {
      return StatusCode(500, $"Internal server error: {ex.Message}");
    }
  }
}
