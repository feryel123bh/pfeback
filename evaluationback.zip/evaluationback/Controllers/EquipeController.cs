using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using evaluationback.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Controllers
{
  [ApiController]
  [Route("api/equipe")]
  public class EquipeController : ControllerBase
  {
    private readonly IEquipeService _equipeService;

    public EquipeController(IEquipeService equipeService)
    {
      _equipeService = equipeService;
    }
    [HttpPost]
    public async Task<IActionResult> CreateEquipe([FromBody] EquipeDto equipeDto)
    {
      Console.WriteLine("Received request payload:");
      Console.WriteLine(JsonConvert.SerializeObject(equipeDto)); // Log payload

      if (equipeDto.ManagerId == null || equipeDto.ManagerId == Guid.Empty)
      {
        return BadRequest("Manager ID is required.");
      }

      if (equipeDto.EmployeeIds == null || !equipeDto.EmployeeIds.Any())
      {
        return BadRequest("At least one employee is required.");
      }

      try
      {
        var createdEquipe = await _equipeService.AddEquipeAsync(equipeDto);
        return CreatedAtAction(nameof(GetEquipeById), new { id = createdEquipe.Id }, createdEquipe);
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error creating team: " + ex.Message); // Log the exception
        return BadRequest($"Error creating team: {ex.Message}");
      }
    }


    [HttpGet("{id}")]
    public async Task<IActionResult> GetEquipeById(Guid id)
    {
      var equipe = await _equipeService.GetEquipeByIdAsync(id);
      if (equipe == null)
      {
        return NotFound();
      }
      return Ok(equipe);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateEquipe(Guid id, [FromBody] EquipeDto equipeDto)
    {
      if (id != equipeDto.Id)
      {
        return BadRequest("Mismatched equipe ID");
      }

      try
      {
        await _equipeService.UpdateEquipeAsync(id, equipeDto);
        return NoContent();
      }
      catch (ArgumentException)
      {
        return NotFound("Equipe not found");
      }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteEquipe(Guid id)
    {
      try
      {
        await _equipeService.DeleteEquipeAsync(id);
        return NoContent();
      }
      catch (ArgumentException)
      {
        return NotFound();
      }
    }

    [HttpGet]
    public async Task<IActionResult> GetAllEquipes()
    {
      var equipes = await _equipeService.GetAllEquipesAsync();
      return Ok(equipes);
    }

    [HttpPost("{id}/addEmployee")]
    public async Task<IActionResult> AddEmployeeToEquipe(Guid id, [FromBody] Guid employeeId)
    {
      await _equipeService.AddEmployeeToEquipeAsync(id, employeeId);
      return NoContent();
    }

    [HttpDelete("{id}/removeEmployee/{employeeId}")]
    public async Task<IActionResult> RemoveEmployeeFromEquipe(Guid id, Guid employeeId)
    {
      await _equipeService.RemoveEmployeeFromEquipeAsync(id, employeeId);
      return NoContent();
    }

    [HttpPost("{id}/assignManager")]
    public async Task<IActionResult> AssignManagerToEquipe(Guid id, [FromBody] Guid managerId)
    {
      try
      {
        await _equipeService.AssignManagerToEquipeAsync(id, managerId);
        return NoContent();
      }
      catch (ArgumentException ex)
      {
        return BadRequest(ex.Message);
      }
    }

    [HttpGet("{id}/employees")]
    public async Task<IActionResult> GetEmployeesInEquipe(Guid id)
    {
      try
      {
        var employees = await _equipeService.GetEmployeesInEquipeAsync(id);
        return Ok(employees);
      }
      catch (ArgumentException)
      {
        return NotFound("Equipe not found");
      }
    }

    [HttpGet("export")]
    public IActionResult ExportEquipesToExcel()
    {
      try
      {
        var content = _equipeService.ExportEquipesToExcel();
        var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        var fileName = "Equipes.xlsx";

        return File(content, contentType, fileName);
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Erreur lors de l'exportation des équipes: {ex.Message}");
      }
    }
  }
}
