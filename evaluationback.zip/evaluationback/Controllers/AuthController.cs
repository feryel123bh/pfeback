using Microsoft.AspNetCore.Mvc;
using evaluationback.Models.DTO;
using evaluationback.Services;
using System.Threading.Tasks;
using System;
using System.Security.Claims;
using evaluationback.Data;
using Microsoft.EntityFrameworkCore;
using evaluationback.Models.Domain;
using System.Text;
using System.Security.Cryptography;

namespace evaluationback.Controllers
{
  [ApiController]
  [Route("api/Auth")]
  public class AuthController : ControllerBase
  {
    private readonly AuthenticationService _authenticationService;
    private readonly Dbcontext _dbContext;

    public AuthController(AuthenticationService authenticationService, Dbcontext dbContext)
    {
      _authenticationService = authenticationService;
      _dbContext = dbContext;
    }

    // Registration method
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
      // Check if the username already exists
      if (await _dbContext.Employees.AnyAsync(u => u.Username == request.Username))
      {
        return BadRequest(new { message = "Username already exists" });
      }

      // Create a new employee with the provided information
      var user = new Employee
      {
        Id = Guid.NewGuid(),
        Username = request.Username,
        Password = ComputeSha256Hash(request.Password), // Hash the password
        Email = request.Email,
        Nom = request.Nom,
        Adresse = request.Adresse,
        Poste = request.Poste,
        Status = true, // By default, set the status to active
        Role = Role.EmployeSimple, // Assign a default role
        Daterec = DateTime.UtcNow,
        Datenaissance = DateTime.UtcNow // Example value, modify accordingly
      };

      // Add the new employee to the database and save changes
      _dbContext.Employees.Add(user);
      await _dbContext.SaveChangesAsync();

      // Return a success message
      return Ok(new { message = "Registration successful" });
    }

    // Helper method to hash passwords using SHA256
    private string ComputeSha256Hash(string rawData)
    {
      using (var sha256Hash = SHA256.Create())
      {
        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < bytes.Length; i++)
        {
          builder.Append(bytes[i].ToString("x2"));
        }
        return builder.ToString();
      }
    }

    // Login method
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
      try
      {
        // Log the received username
        Console.WriteLine($"Login attempt for username: {request.Username}");

        var result = await _authenticationService.AuthenticateAsync(request);

        if (result == null)
        {
          // Log if authentication failed
          Console.WriteLine($"Authentication failed for username: {request.Username}");
          return Unauthorized(new { message = "Invalid username or password" });
        }

        // Log if authentication succeeded
        Console.WriteLine($"Authentication succeeded for username: {request.Username}");
        return Ok(new LoginResponse { Token = result });
      }
      catch (Exception ex)
      {
        // Log any exception that occurred during login
        Console.WriteLine($"An error occurred during login: {ex.Message}");
        return StatusCode(500, new { message = "An internal server error occurred" });
      }
    }

    [HttpGet("details")]
    public async Task<IActionResult> GetUserDetails()
    {
      var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

      if (userId == null)
      {
        return Unauthorized(new { message = "User not authorized" });
      }

      if (!Guid.TryParse(userId, out Guid parsedUserId))
      {
        return BadRequest(new { message = "Invalid User ID" });
      }

      Console.WriteLine($"Fetching details for User ID: {parsedUserId}");

      var user = await _dbContext.Employees
          .Where(e => e.Id == parsedUserId)
          .Select(e => new
          {
            e.Username,
            e.Nom,
            e.Email,
            e.Role
          })
          .FirstOrDefaultAsync();

      if (user == null)
      {
        return NotFound(new { message = "User not found" });
      }

      return Ok(new { name = user.Nom, username = user.Username, email = user.Email, role = user.Role });
    }
  }
}
