using evaluationback.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace evaluationback.Data
{
  public class Dbcontext : DbContext
  {
    public Dbcontext(DbContextOptions<Dbcontext> options) : base(options) { }

    public DbSet<SubObjectif> SubObjectifs { get; set; }
    public DbSet<Option> Options { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Equipe> Equipes { get; set; }
    public DbSet<Campagne> Campagnes { get; set; }
    public DbSet<Evaluation> Evaluations { get; set; }
    public DbSet<CampaignReport> CampaignReports { get; set; }
    public DbSet<Interview> Interviews { get; set; }
    public DbSet<Formulaire> Formulaires { get; set; }
    public DbSet<Section> Sections { get; set; }
    public DbSet<Field> Fields { get; set; }
  public DbSet<FieldResponse> FieldResponses { get; set; }
    public DbSet<Objectif> Objectifs { get; set; }
    public DbSet<EmployeeInterview> EmployeeInterviews { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      base.OnModelCreating(modelBuilder);

      // Employee-Equipe relation
      modelBuilder.Entity<Employee>()
          .HasOne(e => e.Equipe)
          .WithMany(d => d.Employees)
          .HasForeignKey(e => e.EquipeId)
          .IsRequired(false)
          .OnDelete(DeleteBehavior.SetNull); // Set Null if the team is deleted

      // Equipe-Manager relation
      modelBuilder.Entity<Equipe>()
          .HasOne(e => e.Manager)
          .WithMany()
          .HasForeignKey(e => e.ManagerId)
          .OnDelete(DeleteBehavior.Restrict); // Restrict deletion to avoid cycles

      // Campagne-Formulaire relation
      modelBuilder.Entity<Campagne>()
          .HasOne(c => c.Formulaire)
          .WithMany()
          .HasForeignKey(c => c.FormulaireId)
          .OnDelete(DeleteBehavior.SetNull);

      // Campagne-Manager relation
      modelBuilder.Entity<Campagne>()
          .HasOne(c => c.Manager)
          .WithMany()
          .HasForeignKey(c => c.ManagerId)
          .OnDelete(DeleteBehavior.Restrict);

      // Campagne-Equipe relation
      modelBuilder.Entity<Campagne>()
          .HasMany(c => c.Equipes)
          .WithOne()
          .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Campagne to Equipes

      // Campagne-NotifiedEmployees (many-to-many)
      modelBuilder.Entity<Campagne>()
          .HasMany(c => c.NotifiedEmployees)
          .WithMany()
          .UsingEntity(j => j.ToTable("CampagneNotifiedEmployees"));

      // Campagne-CampaignReport relation
      modelBuilder.Entity<Campagne>()
          .HasOne(c => c.CampaignReport)
          .WithOne(r => r.Campagne)
          .HasForeignKey<CampaignReport>(r => r.CampagneId)
          .OnDelete(DeleteBehavior.Cascade); // Cascade delete from Campagne to CampaignReport

      // Interview-Manager relation
      modelBuilder.Entity<Interview>()
          .HasOne(i => i.Manager)
          .WithMany()
          .HasForeignKey(i => i.ManagerId)
          .OnDelete(DeleteBehavior.Restrict); // Restrict deletion to avoid cycles

      // Interview-Campagne relation
      modelBuilder.Entity<Interview>()
          .HasOne(i => i.Campagne)
          .WithMany()
          .HasForeignKey(i => i.CampagneId)
          .OnDelete(DeleteBehavior.Cascade);

      // EmployeeInterview (many-to-many between Interview and Employees)
      modelBuilder.Entity<EmployeeInterview>()
          .HasKey(ei => new { ei.EmployeeId, ei.InterviewId });

      modelBuilder.Entity<EmployeeInterview>()
          .HasOne(ei => ei.Employee)
          .WithMany(e => e.EmployeeInterviews)
          .HasForeignKey(ei => ei.EmployeeId)
          .OnDelete(DeleteBehavior.Cascade);

      modelBuilder.Entity<EmployeeInterview>()
          .HasOne(ei => ei.Interview)
          .WithMany(i => i.EmployeeInterviews)
          .HasForeignKey(ei => ei.InterviewId)
          .OnDelete(DeleteBehavior.Cascade);

      // Evaluation-Employee relation
      modelBuilder.Entity<Evaluation>()
          .HasOne(e => e.Employee)
          .WithMany(e => e.Evaluations)
          .HasForeignKey(e => e.EmployeeId)
          .OnDelete(DeleteBehavior.Cascade);
      // Configuring the one-to-many relationship between Field and FieldResponse
      modelBuilder.Entity<Field>()
          .HasMany(f => f.Responses)
          .WithOne(fr => fr.Field)
          .HasForeignKey(fr => fr.FieldId)
          .OnDelete(DeleteBehavior.Cascade);

      // Section-Formulaire relation
      modelBuilder.Entity<Section>()
          .HasOne(s => s.Formulaire)
          .WithMany(f => f.Sections)
          .HasForeignKey(s => s.FormulaireId)
          .OnDelete(DeleteBehavior.Cascade);

      // Field-Section relation
      modelBuilder.Entity<Field>()
          .HasOne(f => f.Section)
          .WithMany(s => s.Fields)
          .HasForeignKey(f => f.SectionId)
          .OnDelete(DeleteBehavior.Cascade);

      // Objectif-Employee relation
      modelBuilder.Entity<Objectif>()
          .HasOne(o => o.Employee)
          .WithMany(e => e.Objectifs)
          .HasForeignKey(o => o.EmployeeId)
          .OnDelete(DeleteBehavior.Cascade);

      // SubObjectif-Objectif relation
      modelBuilder.Entity<SubObjectif>()
          .HasOne(so => so.Objectif)
          .WithMany(o => o.SubObjectifs)
          .HasForeignKey(so => so.ObjectifId)
          .OnDelete(DeleteBehavior.Cascade);

      // Convert Enum properties to string
      modelBuilder.Entity<Employee>()
          .Property(e => e.Role)
          .HasConversion(
              v => v.ToString(),
              v => (Role)Enum.Parse(typeof(Role), v));

      modelBuilder.Entity<Campagne>()
          .Property(c => c.CampaignType)
          .HasConversion(
              v => v.ToString(),
              v => (CampaignType)Enum.Parse(typeof(CampaignType),v));

      modelBuilder.Entity<Objectif>()
          .Property(o => o.Status)
          .HasConversion(
              v => v.ToString(),
              v => (ObjectifStatus)Enum.Parse(typeof(ObjectifStatus), v));

      modelBuilder.Entity<Campagne>()
          .Property(c => c.Status)
          .HasConversion(
              v => v.ToString(),
              v => (Status)Enum.Parse(typeof(Status), v));


      modelBuilder.Entity<Equipe>()
         .Property(e => e.Status)
         .HasConversion(
             v => v.ToString(),
             v => (EquipeStatus)Enum.Parse(typeof(EquipeStatus), v));
    }
  }
}
