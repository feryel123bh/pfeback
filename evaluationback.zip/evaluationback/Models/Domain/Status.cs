namespace evaluationback.Models.Domain
{
    public enum Status
    {
        Encours,
        Terminée,
        Aréaliser 
    }
}
