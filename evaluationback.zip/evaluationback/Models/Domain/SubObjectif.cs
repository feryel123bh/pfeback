namespace evaluationback.Models.Domain
{
  public class SubObjectif
  {
    public Guid Id { get; set; }  // Identifiant unique du sous-objectif
    public string? Title { get; set; }  // Titre du sous-objectif
    public int? Progress { get; set; }  // Progression du sous-objectif en pourcentage
    public bool Completed { get; set; }  // Indicateur si le sous-objectif est complété ou non
    public Guid ObjectifId { get; set; }  // Référence à l'objectif principal auquel ce sous-objectif est associé
    public Objectif? Objectif { get; set; }  // Lien vers l'objectif principal (relation de navigation)
  }
}
