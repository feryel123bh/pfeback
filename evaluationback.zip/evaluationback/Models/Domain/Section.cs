using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class Section
  {
    [Key]
    public Guid Id { get; set; }
    public string? Title { get; set; }
    public int Order { get; set; } // Ordre de la section dans le formulaire

    public Guid FormulaireId { get; set; }
    public Formulaire? Formulaire { get; set; }

    public List<Field> Fields { get; set; } = new List<Field>();
  }

}
