using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class CampaignReport
  {
    [Key]
    public Guid Id { get; set; } // Unique identifier for the report

    public Guid CampagneId { get; set; }
    public Campagne? Campagne { get; set; } // Navigation property

    public string? Titre { get; set; }
    public DateTime DateDebut { get; set; }
    public DateTime DateFin { get; set; }
    public int TotalEmployees { get; set; }
    public int CompletedEvaluations { get; set; }
    public int PendingEvaluations { get; set; }
    public double AverageScore { get; set; }
    public List<string> Comments { get; set; } = new List<string>();
  }
}
