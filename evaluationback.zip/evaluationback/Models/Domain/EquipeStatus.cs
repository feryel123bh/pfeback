namespace evaluationback.Models.Domain
{
  public enum EquipeStatus
  {
    Active,
    Inactive
  }
}
