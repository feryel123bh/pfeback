using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
    public class EmployeeInterview
    {
    [Key]
    public Guid Id { get; set; }
    public Guid EmployeeId { get; set; }
    public Employee? Employee { get; set; }

    public Guid InterviewId { get; set; }
    public Interview? Interview { get; set; }
  }
}
