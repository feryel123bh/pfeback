namespace evaluationback.Models.Domain
{
    public enum CampaignType
    {
        Annuelle,
        Semestrielle,
        Trimestrielle
    }
}
