using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace evaluationback.Models.Domain
{
  public class Equipe
  {
    [Key]
    public Guid Id { get; set; }
    public string? Name { get; set; }
    [EnumDataType(typeof(EquipeStatus))]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public EquipeStatus Status { get; set; }


    public Guid? ManagerId { get; set; }
    public Employee? Manager { get; set; }

    public ICollection<Employee> Employees { get; set; } = new List<Employee>();
  }

}
