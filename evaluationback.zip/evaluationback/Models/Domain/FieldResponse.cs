using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class FieldResponse
  {
    [Key]
    public Guid Id { get; set; }

    public Guid FieldId { get; set; }  // Link to the specific form field
    public Field? Field { get; set; }  // Navigation property

    public Guid EmployeeId { get; set; }  // Link to the employee responding
    public Employee? Employee { get; set; }  // Navigation property

    public string? ResponseValue { get; set; }  // The employee's response, stored as JSON

    public DateTime DateSubmitted { get; set; } = DateTime.UtcNow;  // Submission date

  }
}
