﻿namespace evaluationback.Models.Domain
{

    public enum Role
    {
        EmployeSimple,
        Manager,
        Rh
    }


}
