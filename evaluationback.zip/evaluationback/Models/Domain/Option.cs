using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class Option
  {
    [Key]
    public Guid IdOp { get; set; }
    public string? Label { get; set; }
    public string? Value { get; set; }
  }
}
