using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static System.Collections.Specialized.BitVector32;

namespace evaluationback.Models.Domain
{
  public class Formulaire
  {
    [Key]
    public Guid Id { get; set; }
    public string ? Title { get; set; }
    public DateTime DateCreated { get; set; } = DateTime.UtcNow;

    // Navigation property pour les sections
    public List<Section> Sections { get; set; } = new List<Section>();
   
  }

}
