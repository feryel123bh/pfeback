using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace evaluationback.Models.Domain
{
  public class Campagne
  {
    [Key]
    public Guid Id { get; set; }

    public string? Titre { get; set; }
    public string? Description { get; set; }

    [EnumDataType(typeof(CampaignType))]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public CampaignType? CampaignType { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    public Guid? FormulaireId { get; set; }
    public Formulaire? Formulaire { get; set; }

    public Guid ManagerId { get; set; }
    public Employee? Manager { get; set; }

    [EnumDataType(typeof(Status))]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public Status Status { get; set; } 

    // Relationship with CampaignReport
    public CampaignReport? CampaignReport { get; set; } // This is the property that needs to be in place

    public ICollection<Equipe> Equipes { get; set; } = new List<Equipe>();
    public ICollection<Employee> NotifiedEmployees { get; set; } = new List<Employee>();
  }
}
