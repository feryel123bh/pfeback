using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace evaluationback.Models.Domain
{
  public class Employee
  {
    [Key]
    public Guid Id { get; set; }
    public string? Nom { get; set; }
    public string? Prenom { get; set; }
    public string? Email { get; set; }
    public DateTime Datenaissance { get; set; }
    public DateTime Daterec { get; set; }
    public string? Username { get; set; }
    public string? Password { get; set; }
    public string ?Adresse { get; set; }
    public string? Poste { get; set; }
    public bool Status { get; set; }

    [EnumDataType(typeof(Role))]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public Role Role { get; set; }

    public Guid? EquipeId { get; set; }
    public Equipe? Equipe { get; set; }
    public Interview? Interview { get; set; }

    public ICollection<EmployeeInterview>? EmployeeInterviews { get; set; }
    public ICollection<Objectif> Objectifs { get; set; } = new List<Objectif>();
    public ICollection<Evaluation> Evaluations { get; set; } = new List<Evaluation>();
  }
}
