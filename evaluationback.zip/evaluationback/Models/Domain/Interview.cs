using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class Interview
  {
    [Key]
    public Guid Id { get; set; }

    public Guid ManagerId { get; set; }
    public Employee? Manager { get; set; }

    public ICollection<EmployeeInterview> EmployeeInterviews { get; set; } = new List<EmployeeInterview>();
    public ICollection<Evaluation> Evaluations { get; set; } = new List<Evaluation>();

    public DateTime Date { get; set; }
    public Guid CampagneId { get; set; }
    public Campagne? Campagne { get; set; }
  }
}
