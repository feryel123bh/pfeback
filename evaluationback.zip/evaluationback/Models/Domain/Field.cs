using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class Field
  {

    [Key]
    public Guid Id { get; set; }
    public string? FieldType { get; set; } // Type du champ (ex: "TextInput", "NumberInput")
    public string? Label { get; set; } // Label affiché pour le champ
    public string? Placeholder { get; set; } // Texte de substitution pour le champ
    public bool IsRequired { get; set; } // Champ requis ou non
    public int Span { get; set; } // Largeur du champ (colspan)
    public bool IsHelpBlockVisible { get; set; } // Indique si le bloc d'aide est visible
    public string ?HelpBlockText { get; set; } // Texte d'aide

    public Guid SectionId { get; set; }
    public Section? Section { get; set; }

    public string? OptionsJson { get; set; }

    public ICollection<FieldResponse> Responses { get; set; } = new List<FieldResponse>();
  }

}
