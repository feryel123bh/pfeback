using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace evaluationback.Models.Domain
{
  public class Objectif
  {
    [Key]
    public Guid Id { get; set; }
    public string? Description { get; set; }
    public DateTime DateDebut { get; set; }
    public DateTime DateFin { get; set; }
    public int Progress { get; set; }
    public Guid EmployeeId { get; set; }
    public Employee? Employee { get; set; }
    public ObjectifStatus Status { get; set; } = ObjectifStatus.EnCours;
    public int? Note { get; set; }
    public string? Commentaire { get; set; }
    public ICollection<SubObjectif> SubObjectifs { get; set; } = new List<SubObjectif>();
  }

  public enum ObjectifStatus
  {
    Realisable,
    EnCours,
    Complete
  }
}
