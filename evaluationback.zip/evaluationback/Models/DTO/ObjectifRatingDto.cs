namespace evaluationback.Models.DTO
{
  public class ObjectifRatingDto
  {
    public int Note { get; set; }
    public string? Commentaire { get; set; }
  }
}
