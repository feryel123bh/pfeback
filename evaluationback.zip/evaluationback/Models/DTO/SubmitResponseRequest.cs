namespace evaluationback.Models.DTO
{
  public class SubmitResponseRequest
  {
    public Guid FormulaireId { get; set; }
    public string? Question { get; set; }
    public string? Response { get; set; }
  }
}
