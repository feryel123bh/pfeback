namespace evaluationback.Models.DTO
{
  public class OptionDto
  {
    public string? Label { get; set; }
    public string? Value { get; set; }
  }
}
