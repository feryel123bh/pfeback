namespace evaluationback.Models.DTO
{
  public class SectionDto
  {
    public Guid Id { get; set; }
    public string? Title { get; set; }
    public int Order { get; set; }
    public List<FieldDto>? Fields { get; set; }
  }
}
