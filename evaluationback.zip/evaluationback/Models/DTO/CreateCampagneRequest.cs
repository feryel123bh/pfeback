using evaluationback.Models.Domain;

namespace evaluationback.Models.DTO
{
  public class CreateCampagneRequest
  {
    public Campagne? Campagne { get; set; }
    public Guid ManagerId { get; set; }    // Add this property
    public Guid? FormulaireId { get; set; }
  }
}

