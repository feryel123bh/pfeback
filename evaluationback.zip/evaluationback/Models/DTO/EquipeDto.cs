using evaluationback.Models.Domain;

namespace evaluationback.Models.DTO
{
  public class EquipeDto
  {
    public Guid Id { get; set; }
    public string Name { get; set; }
    public EquipeStatus Status { get; set; }
    public Guid? ManagerId { get; set; }
    public List<Guid> EmployeeIds { get; set; } = new List<Guid>(); // This is the list of employee IDs from the frontend

  }
}
