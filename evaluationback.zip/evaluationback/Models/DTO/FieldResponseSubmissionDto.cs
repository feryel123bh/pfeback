namespace evaluationback.Models.DTO
{
  public class FieldResponseSubmissionDto
  {
    public Guid EmployeeId { get; set; }
    public List<FieldResponseDto> FieldResponses { get; set; }

  }
}
