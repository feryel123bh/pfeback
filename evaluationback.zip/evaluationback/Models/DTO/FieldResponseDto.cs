namespace evaluationback.Models.DTO
{
  public class FieldResponseDto
  {
    public Guid FieldId { get; set; }  // ID of the field
    public Guid EmployeeId { get; set; }  // ID of the employee
    public string? ResponseType { get; set; }  // Type of the response (e.g., text, rating)
    public object? ResponseValue { get; set; }  // The actual response value

  }
}
