namespace evaluationback.Models.DTO
{
  public class FieldDto
  {
    public Guid Id { get; set; }
    public string ? FieldType { get; set; }
    public string? Label { get; set; }
    public string? Placeholder { get; set; }
    public bool IsRequired { get; set; }
    public int Span { get; set; }
    public bool IsHelpBlockVisible { get; set; }
    public string? HelpBlockText { get; set; }
    public List<OptionDto>? Options { get; set; } // Utilisé pour SelectList, RadioButton, etc.
  }
}
