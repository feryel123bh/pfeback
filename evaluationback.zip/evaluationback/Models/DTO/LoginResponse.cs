namespace evaluationback.Models.DTO
{
  public class LoginResponse
  {
    public string? Token { get; set; }
  }
}
