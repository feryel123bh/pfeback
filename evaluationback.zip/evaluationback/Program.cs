using evaluationback.Data;
using evaluationback.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using OfficeOpenXml;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configure DbContext with SQL Server
builder.Services.AddDbContext<Dbcontext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("EvaluationConnectionString"),
        sqlServerOptions => sqlServerOptions.MigrationsAssembly("evaluationback"))
);

// Register application services
builder.Services.AddScoped<ICampagneService, CampagneService>();
builder.Services.AddScoped<IEmployeeService, EmployeeService>();
builder.Services.AddScoped<IEquipeService, EquipeService>();
builder.Services.AddScoped<IEvaluationService, EvaluationService>();
builder.Services.AddScoped<IFormulaireService, FormulaireService>();
builder.Services.AddScoped<ICampaignreportService, CampaignreportService>();
builder.Services.AddScoped<IInterviewService, InterviewService>();
builder.Services.AddScoped<IFieldResponseService, FieldResponseService>();
builder.Services.AddScoped<FormulaireService>();
builder.Services.AddScoped<EmailService>();
builder.Services.AddScoped<NotificationService>(); // Adding NotificationService
builder.Services.AddScoped<AuthenticationService>();
builder.Services.AddHttpContextAccessor();
builder.Services.AddControllers();
// Configure Swagger with JWT authentication
builder.Services.AddSwaggerGen(c =>
{
  c.SwaggerDoc("v1", new OpenApiInfo { Title = "Evaluation", Version = "v1" });

  // Add JWT Authentication to Swagger
  c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
  {
    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
    Name = "Authorization",
    In = ParameterLocation.Header,
    Type = SecuritySchemeType.ApiKey,
    Scheme = "Bearer"
  });

  c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// Configure EPPlus license context
ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

// Configure JSON Serializer to avoid reference loop handling issues
builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
  options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
  options.SerializerSettings.ContractResolver = new DefaultContractResolver();
});

// Configure CORS
builder.Services.AddCors(options =>
{
  options.AddPolicy("AllowSpecificOrigin",
      policyBuilder => policyBuilder
          .WithOrigins("http://localhost:8080")
          .AllowAnyHeader()
          .AllowAnyMethod());
});

builder.Services.AddCors(options =>
{
  options.AddPolicy("AllowAll",
      policyBuilder => policyBuilder
          .AllowAnyOrigin()
          .AllowAnyHeader()
          .AllowAnyMethod());
});

// Retrieve JWT secret key from configuration
string jwtKey = builder.Configuration["Jwt:Key"] ?? "DefaultFallbackKey";

// Configure JWT authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
      options.TokenValidationParameters = new TokenValidationParameters
      {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtKey)),
        ValidateIssuer = false,
        ValidateAudience = false
      };
    });

var app = builder.Build();



// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
  app.UseExceptionHandler("/Home/Error");
  app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();


app.UseRouting();
app.UseCors("AllowSpecificOrigin");
app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();

// Enable Swagger UI
app.UseSwagger();
app.UseSwaggerUI(c =>
{
  c.SwaggerEndpoint("/swagger/v1/swagger.json", "Evaluation V1");
});

// Map default controller route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
