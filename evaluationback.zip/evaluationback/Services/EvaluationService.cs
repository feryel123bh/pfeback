using evaluationback.Data;
using evaluationback.Models.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class EvaluationService : IEvaluationService
  {
    private readonly Dbcontext _dbContext;

    public EvaluationService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    // Create a new Evaluation
    public async Task<Evaluation> CreateEvaluationAsync(Evaluation evaluation)
    {
      evaluation.Id = Guid.NewGuid();
      evaluation.Date = DateTime.UtcNow;

      _dbContext.Evaluations.Add(evaluation);
      await _dbContext.SaveChangesAsync();

      return evaluation;
    }

    // Record interview results and create a corresponding evaluation
    public async Task<Evaluation> RecordInterviewResultsAsync(Guid interviewId, Guid employeeId, string comments, int score)
    {
      var interview = await _dbContext.Interviews.FindAsync(interviewId);
      if (interview == null)
      {
        throw new ArgumentException("Interview not found");
      }

      var evaluation = new Evaluation
      {
        Id = Guid.NewGuid(),
        //InterviewId = interviewId,
        EmployeeId = employeeId,
        Comments = comments,
        Score = score,
        Date = DateTime.UtcNow
      };

      _dbContext.Evaluations.Add(evaluation);
      await _dbContext.SaveChangesAsync();

      return evaluation;
    }

   
   

    // Get a single Evaluation by ID
    public async Task<Evaluation> GetEvaluationByIdAsync(Guid evaluationId)
    {
      var evaluation = await _dbContext.Evaluations
                                       .Include(e => e.Employee)
                                       //.Include(e => e.Interview)
                                      // .Include(e => e.Campagnes)
                                       .FirstOrDefaultAsync(e => e.Id == evaluationId);

      if (evaluation == null)
      {
        throw new ArgumentException("Evaluation not found");
      }

      return evaluation;
    }

    // Update an existing Evaluation
    public async Task<Evaluation> UpdateEvaluationAsync(Evaluation updatedEvaluation)
    {
      var existingEvaluation = await _dbContext.Evaluations
                                               .FirstOrDefaultAsync(e => e.Id == updatedEvaluation.Id);

      if (existingEvaluation == null)
      {
        throw new ArgumentException("Evaluation not found");
      }

      existingEvaluation.Description = updatedEvaluation.Description;
      existingEvaluation.Score = updatedEvaluation.Score;
      existingEvaluation.Comments = updatedEvaluation.Comments;
      existingEvaluation.Date = updatedEvaluation.Date;

      _dbContext.Evaluations.Update(existingEvaluation);
      await _dbContext.SaveChangesAsync();

      return existingEvaluation;
    }

    // Delete an Evaluation by ID
    public async Task DeleteEvaluationAsync(Guid evaluationId)
    {
      var evaluation = await _dbContext.Evaluations.FindAsync(evaluationId);
      if (evaluation == null)
      {
        throw new ArgumentException("Evaluation not found");
      }

      _dbContext.Evaluations.Remove(evaluation);
      await _dbContext.SaveChangesAsync();
    }

    // Get all evaluations
    public async Task<List<Evaluation>> GetAllEvaluationsAsync()
    {
      return await _dbContext.Evaluations
                             .Include(e => e.Employee)
                             //.Include(e => e.Interview)
                            // .Include(e => e.Campagnes)
                             .ToListAsync();
    }
  }
}
