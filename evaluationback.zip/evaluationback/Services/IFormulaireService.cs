using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public interface IFormulaireService
  {
    Task<Guid> SaveFormulaireAsync(FormulaireDto formulaireDto);
    Task<Formulaire> GetFormulaireByIdAsync(Guid id);
    Task<List<Formulaire>> GetAllFormulairesAsync();
    Task DeleteFormulaireAsync(Guid id);

    // Add the method signature for updating a Formulaire
    Task UpdateFormulaireAsync(Guid id, FormulaireDto formulaireDto);
  }
}
