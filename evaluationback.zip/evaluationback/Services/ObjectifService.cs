using evaluationback.Data;
using evaluationback.Models.Domain;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace evaluationback.Services
{
  public class ObjectifService
  {
    private readonly Dbcontext _dbContext;

    public ObjectifService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    // Créer un nouvel objectif
    public async Task<Objectif> CreateObjectifAsync(Objectif objectif)
    {
      objectif.Id = Guid.NewGuid();
      _dbContext.Objectifs.Add(objectif);
      await _dbContext.SaveChangesAsync();
      return objectif;
    }

    // Mettre à jour un objectif
    public async Task UpdateObjectifAsync(Objectif objectif)
    {
      var existingObjectif = await _dbContext.Objectifs.FindAsync(objectif.Id);
      if (existingObjectif == null)
      {
        throw new ArgumentException("Objectif not found");
      }

      existingObjectif.Description = objectif.Description;
      existingObjectif.DateDebut = objectif.DateDebut;
      existingObjectif.DateFin = objectif.DateFin;
      existingObjectif.Status = objectif.Status;

      await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateObjectiveStatus(Guid objectiveId, string status)
    {
      var objective = await _dbContext.Objectifs.FindAsync(objectiveId);

      if (objective == null)
      {
        throw new ArgumentException("Objectif introuvable");
      }

      if (Enum.TryParse(status, true, out ObjectifStatus parsedStatus))
      {
        objective.Status = parsedStatus;
      }
      else
      {
        throw new ArgumentException("Statut invalide");
      }

      await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateSubObjective(Guid subObjectiveId, bool completed)
    {
      var subObjective = await _dbContext.SubObjectifs.FindAsync(subObjectiveId);
      if (subObjective == null)
      {
        throw new ArgumentException("Sous-objectif introuvable");
      }

      subObjective.Completed = completed;
      subObjective.Progress = completed ? 100 : subObjective.Progress;
      await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateObjectiveProgress(Guid objectiveId, int progress)
    {
      var objective = await _dbContext.Objectifs.FindAsync(objectiveId);
      if (objective == null)
      {
        throw new ArgumentException("Objectif introuvable");
      }

      objective.Progress = progress;
      await _dbContext.SaveChangesAsync();
    }

    // Noter et commenter un objectif
    public async Task NoterObjectifAsync(Guid objectifId, int note, string commentaire)
    {
      var objectif = await _dbContext.Objectifs.FindAsync(objectifId);
      if (objectif == null)
      {
        throw new ArgumentException("Objectif not found");
      }

      objectif.Note = note;
      objectif.Commentaire = commentaire;
      await _dbContext.SaveChangesAsync();
    }

    // Suivre les objectifs par employé
    public async Task<List<Objectif>> GetObjectifsByEmployeeAsync(Guid employeeId)
    {
      return await _dbContext.Objectifs
                             .Where(o => o.EmployeeId == employeeId)
                             .ToListAsync();
    }

    // Récupérer un objectif par ID
    public async Task<Objectif> GetObjectifByIdAsync(Guid objectifId)
    {
      var objectif = await _dbContext.Objectifs.FindAsync(objectifId);

      if (objectif == null)
      {
        throw new KeyNotFoundException($"Objectif with ID {objectifId} was not found.");
      }

      return objectif;
    }

    // Récupérer tous les objectifs (pour les rapports ou le suivi global)
    public async Task<List<Objectif>> GetAllObjectifsAsync()
    {
      return await _dbContext.Objectifs.ToListAsync();
    }
  }
}
