using evaluationback.Data;
using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class EquipeService : IEquipeService
  {
    private readonly Dbcontext _dbContext;

    public EquipeService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    public async Task<Equipe> AddEquipeAsync(EquipeDto equipeDto)
    {
      var equipe = MapDtoToEquipe(equipeDto);
      equipe.Id = Guid.NewGuid();

      Console.WriteLine($"Adding equipe: {equipe.Name}, Manager: {equipeDto.ManagerId}");

      _dbContext.Equipes.Add(equipe);

      var employees = await _dbContext.Employees
          .Where(e => equipeDto.EmployeeIds.Contains(e.Id))
          .ToListAsync();

      Console.WriteLine($"Assigning {employees.Count} employees to equipe.");

      foreach (var employee in employees)
      {
        employee.EquipeId = equipe.Id;
      }

      var manager = await _dbContext.Employees.FindAsync(equipeDto.ManagerId);
      if (manager == null)
      {
        throw new Exception("Manager not found");
      }

      manager.EquipeId = equipe.Id;

      await _dbContext.SaveChangesAsync();
      return equipe;
    }



    public async Task<Equipe> GetEquipeByIdAsync(Guid id)
    {
      var equipe = await _dbContext.Equipes
                                   .Include(e => e.Employees)
                                   .Include(e => e.Manager)
                                   .FirstOrDefaultAsync(e => e.Id == id);
      if (equipe == null)
      {
        throw new ArgumentException("Equipe not found");
      }
      return equipe;
    }

    public async Task<IEnumerable<Equipe>> GetAllEquipesAsync()
    {
      return await _dbContext.Equipes
          .Include(e => e.Manager)
          .Include(e => e.Employees)
          .ToListAsync();
    }

    public async Task<Equipe> UpdateEquipeAsync(Guid id, EquipeDto updatedEquipe)
    {
      var equipe = await _dbContext.Equipes.FindAsync(id);
      if (equipe == null)
      {
        throw new ArgumentException("Equipe not found");
      }

      equipe.Name = updatedEquipe.Name;
      equipe.Status = updatedEquipe.Status;

      // Handle updating employees if needed
      equipe.Employees.Clear();
      foreach (var employeeId in updatedEquipe.EmployeeIds)
      {
        var employee = await _dbContext.Employees.FindAsync(employeeId);
        if (employee != null && employee.Role == Role.EmployeSimple)
        {
          employee.EquipeId = equipe.Id;
          equipe.Employees.Add(employee);
        }
      }

      await _dbContext.SaveChangesAsync();
      return equipe;
    }

    public async Task DeleteEquipeAsync(Guid id)
    {
      var equipe = await _dbContext.Equipes.FindAsync(id);
      if (equipe == null)
      {
        throw new ArgumentException("Equipe not found");
      }

      _dbContext.Equipes.Remove(equipe);
      await _dbContext.SaveChangesAsync();
    }

    public async Task AddEmployeeToEquipeAsync(Guid equipeId, Guid employeeId)
    {
      var equipe = await _dbContext.Equipes.FindAsync(equipeId);
      var employee = await _dbContext.Employees.FindAsync(employeeId);

      if (equipe == null || employee == null)
      {
        throw new ArgumentException("Equipe or Employee not found");
      }

      employee.EquipeId = equipeId;
      equipe.Employees.Add(employee);
      await _dbContext.SaveChangesAsync();
    }

    public async Task RemoveEmployeeFromEquipeAsync(Guid equipeId, Guid employeeId)
    {
      var equipe = await _dbContext.Equipes.FindAsync(equipeId);
      var employee = await _dbContext.Employees.FindAsync(employeeId);

      if (equipe == null || employee == null)
      {
        throw new ArgumentException("Equipe or Employee not found");
      }

      employee.EquipeId = null;
      equipe.Employees.Remove(employee);
      await _dbContext.SaveChangesAsync();
    }

    public async Task AssignManagerToEquipeAsync(Guid equipeId, Guid managerId)
    {
      var equipe = await _dbContext.Equipes.FindAsync(equipeId);
      var manager = await _dbContext.Employees.FindAsync(managerId);

      if (equipe == null)
      {
        throw new ArgumentException("Equipe not found");
      }

      if (manager == null || manager.Role != Role.Manager)
      {
        throw new ArgumentException("Manager not found or not a valid manager");
      }

      equipe.ManagerId = managerId;
      equipe.Manager = manager;

      await _dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<Employee>> GetEmployeesInEquipeAsync(Guid equipeId)
    {
      var equipe = await _dbContext.Equipes
                                   .Include(e => e.Employees)
                                   .FirstOrDefaultAsync(e => e.Id == equipeId);
      if (equipe == null)
      {
        throw new ArgumentException("Equipe not found");
      }

      return equipe.Employees;
    }

    public byte[] ExportEquipesToExcel()
    {
      ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

      using (var package = new ExcelPackage())
      {
        var worksheet = package.Workbook.Worksheets.Add("Equipes");

        worksheet.Cells[1, 1].Value = "Id";
        worksheet.Cells[1, 2].Value = "Nom de l'équipe";
        worksheet.Cells[1, 3].Value = "Status";
        worksheet.Cells[1, 4].Value = "Manager";
        worksheet.Cells[1, 5].Value = "Employés";

        var equipes = _dbContext.Equipes.Include(e => e.Manager).Include(e => e.Employees).ToList();
        for (int i = 0; i < equipes.Count; i++)
        {
          var equipe = equipes[i];
          worksheet.Cells[i + 2, 1].Value = equipe.Id;
          worksheet.Cells[i + 2, 2].Value = equipe.Name;
          worksheet.Cells[i + 2, 3].Value = equipe.Status.ToString(); // Convert enum to string for Excel
          worksheet.Cells[i + 2, 4].Value = equipe.Manager != null ? $"{equipe.Manager.Nom} {equipe.Manager.Prenom}" : "N/A";
          worksheet.Cells[i + 2, 5].Value = string.Join(", ", equipe.Employees.Select(e => $"{e.Nom} {e.Prenom}"));
        }

        worksheet.Cells.AutoFitColumns();

        return package.GetAsByteArray();
      }
    }

    // Helper method to map EquipeDto to Equipe
    private Equipe MapDtoToEquipe(EquipeDto dto)
    {
      var equipe = new Equipe
      {
        Id = dto.Id,
        Name = dto.Name,
        Status = dto.Status, // Using the enum directly
        ManagerId = dto.ManagerId
      };

      if (dto.EmployeeIds != null && dto.EmployeeIds.Any())
      {
        equipe.Employees = dto.EmployeeIds.Select(id => new Employee { Id = id }).ToList();
      }

      return equipe;
    }
  }
}
