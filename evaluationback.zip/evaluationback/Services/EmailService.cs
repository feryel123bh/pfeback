using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace evaluationback.Services
{
  public class EmailService
  {
    private readonly IConfiguration _configuration;

    public EmailService(IConfiguration configuration)
    {
      _configuration = configuration;
    }

    public async Task SendNotificationAsync(string toEmail, string subject, string message)
    {
      var smtpClient = new SmtpClient(_configuration["Email:Smtp:Host"])
      {
        Port = int.Parse(_configuration["Email:Smtp:Port"]),
        Credentials = new NetworkCredential(_configuration["Email:Smtp:Username"], _configuration["Email:Smtp:Password"]),
        EnableSsl = true,
      };

      var mailMessage = new MailMessage
      {
        From = new MailAddress(_configuration["Email:From"]),
        Subject = subject,
        Body = message,
        IsBodyHtml = true,
      };
      mailMessage.To.Add(toEmail);

      try
      {
        await smtpClient.SendMailAsync(mailMessage);
      }
      catch (SmtpException ex)
      {
        throw new InvalidOperationException($"Error sending email: {ex.Message}", ex);
      }
    }
  }
}
