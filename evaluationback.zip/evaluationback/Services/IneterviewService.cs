using evaluationback.Data;
using evaluationback.Models.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class InterviewService : IInterviewService
  {
    private readonly Dbcontext dbContext;
    private readonly NotificationService _notificationService;

    public InterviewService(Dbcontext dbcontext, NotificationService notificationService)
    {
      dbContext = dbcontext;
      _notificationService = notificationService;
    }

    public async Task ScheduleInterviewAsync(Guid campagneId, Guid managerId, List<Guid> employeeIds, DateTime interviewDate)
    {
      foreach (var employeeId in employeeIds)
      {
        var interview = new Interview
        {
          Id = Guid.NewGuid(),
          ManagerId = managerId,
          Date = interviewDate,
          CampagneId = campagneId
        };

        interview.EmployeeInterviews.Add(new EmployeeInterview
        {
          Id = Guid.NewGuid(),
          EmployeeId = employeeId,
          InterviewId = interview.Id
        });

        dbContext.Interviews.Add(interview);
        await dbContext.SaveChangesAsync();

        // Notify employee of the scheduled interview
        var employee = await dbContext.Employees.FindAsync(employeeId);
        if (employee != null)
        {
          await _notificationService.SendNotificationAsync(employee.Email,
              "Entretien Programmé",
              $"Un entretien a été programmé pour vous le {interviewDate.ToString("f")}");
        }
      }
    }

    public async Task CancelInterviewAsync(Guid interviewId)
    {
      var interview = await dbContext.Interviews.FindAsync(interviewId);
      if (interview == null)
      {
        throw new ArgumentException("Interview not found");
      }

      dbContext.Interviews.Remove(interview);
      await dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<Interview>> GetInterviewsByEmployeeAsync(Guid employeeId)
    {
      return await dbContext.Interviews
                            .Include(i => i.EmployeeInterviews)
                            .Where(i => i.EmployeeInterviews.Any(ei => ei.EmployeeId == employeeId))
                            .ToListAsync();
    }
  }
}
