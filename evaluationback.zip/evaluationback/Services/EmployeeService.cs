using evaluationback.Data;
using evaluationback.Models.Domain;
using Microsoft.AspNetCore.Http;
using OfficeOpenXml;
using System.IO;
using System.Net.Mail;
using System.Net;
using System.Security.Claims;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace evaluationback.Services
{
  public class EmployeeService : IEmployeeService
  {
    private readonly Dbcontext dbContext;
    private readonly IConfiguration _configuration;
    private readonly IHttpContextAccessor httpContextAccessor;
    private readonly ILogger<EmployeeService> _logger;

    public EmployeeService(Dbcontext dbContext, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, ILogger<EmployeeService> logger)
    {
      this.dbContext = dbContext;
      _logger = logger;
      this._configuration = configuration;
      this.httpContextAccessor = httpContextAccessor;
    }

    private Employee GetCurrentUser()
    {
      var userIdClaim = httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier);
      if (userIdClaim == null)
      {
        return null; // No user logged in
      }

      var userId = Guid.Parse(userIdClaim.Value);
      var currentUser = dbContext.Set<Employee>().SingleOrDefault(e => e.Id == userId);

      return currentUser;
    }

    private bool IsCurrentUserRH()
    {
      var currentUser = GetCurrentUser();
      return currentUser != null && currentUser.Role == Role.Rh;
    }

    public async Task<Employee> AddEmployee(Employee employee)
    {
      if (!IsCurrentUserRH())
      {
        throw new UnauthorizedAccessException("Only RH role can add employees.");
      }

      employee.Id = Guid.NewGuid();
      employee.Password = GeneratePassword();
      dbContext.Employees.Add(employee);
      await dbContext.SaveChangesAsync();

      await SendPasswordEmailAsync(employee.Email, employee.Username, employee.Password);

      return employee;
    }

    private async Task SendPasswordEmailAsync(string toEmail, string username, string password)
    {
      var smtpClient = new SmtpClient(_configuration["Email:Smtp:Host"])
      {
        Port = int.Parse(_configuration["Email:Smtp:Port"]),
        Credentials = new NetworkCredential(_configuration["Email:Smtp:Username"], _configuration["Email:Smtp:Password"]),
        EnableSsl = true,
      };

      var mailMessage = new MailMessage
      {
        From = new MailAddress(_configuration["Email:From"]),
        Subject = "Your account details",
        Body = $"<p>Dear {username},</p><p>Your account has been created. Here are your login details:</p><p>Username: {username}<br>Password: {password}</p><p>Please change your password after your first login.</p>",
        IsBodyHtml = true,
      };
      mailMessage.To.Add(toEmail);

      await smtpClient.SendMailAsync(mailMessage);
    }

    private string GeneratePassword()
    {
      return Guid.NewGuid().ToString("N").Substring(0, 8);
    }

    public async Task<IEnumerable<Employee>> GetAllEmployeesAsync()
    {
      return await dbContext.Employees
                            .Include(e => e.Objectifs)
                            .Include(e => e.Evaluations)
                            .ToListAsync();
    }

    public async Task<IEnumerable<Employee>> GetAllManagersAsync()
    {
      Role managerRole = Role.Manager;
      var managers = await dbContext.Employees
          .Where(e => e.Role == managerRole)
          .ToListAsync();

      _logger.LogInformation($"Found {managers.Count} managers.");
      return managers;
    }

    public async Task<Employee> GetEmployeeById(Guid id)
    {
      var employee = await dbContext.Employees
                                    .Include(e => e.Objectifs)
                                    .Include(e => e.Evaluations)
                                    .FirstOrDefaultAsync(e => e.Id == id);
      if (employee == null)
      {
        throw new ArgumentException("Employee not found");
      }
      return employee;
    }

    public async Task<Employee> UpdateEmployee(Guid id, Employee updatedEmployee)
    {
      var employee = await dbContext.Employees.FindAsync(id);
      if (employee == null)
      {
        throw new ArgumentException("Employee not found");
      }

      employee.Nom = updatedEmployee.Nom;
      employee.Email = updatedEmployee.Email;
      employee.Datenaissance = updatedEmployee.Datenaissance;
      employee.Daterec = updatedEmployee.Daterec;
      employee.Username = updatedEmployee.Username;
      employee.Password = updatedEmployee.Password;
      employee.Adresse = updatedEmployee.Adresse;
      employee.Poste = updatedEmployee.Poste;
      employee.Status = updatedEmployee.Status;

      await dbContext.SaveChangesAsync();

      return employee;
    }
    public async Task<IEnumerable<Employee>> GetEmployeesByRoleAsync(Role role)
    {
      return await dbContext.Employees
                            .Where(e => e.Role == role)
                            .Include(e => e.Objectifs)
                            .Include(e => e.Evaluations)
                            .ToListAsync();
    }

    public async Task DeleteEmployee(Guid id)
    {
      var employee = await dbContext.Employees.FindAsync(id);
      if (employee == null)
      {
        throw new ArgumentException("Employee not found");
      }

      dbContext.Employees.Remove(employee);
      await dbContext.SaveChangesAsync();
    }

    public byte[] ExportEmployeesToExcel()
    {
      ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

      using (var package = new ExcelPackage())
      {
        var worksheet = package.Workbook.Worksheets.Add("Employees");

        worksheet.Cells[1, 1].Value = "Id";
        worksheet.Cells[1, 2].Value = "Nom";
        worksheet.Cells[1, 3].Value = "Email";
        worksheet.Cells[1, 4].Value = "Date de naissance";
        worksheet.Cells[1, 5].Value = "Date de recrutement";
        worksheet.Cells[1, 6].Value = "Username";
        worksheet.Cells[1, 7].Value = "Password";
        worksheet.Cells[1, 8].Value = "Adresse";
        worksheet.Cells[1, 9].Value = "Poste";
        worksheet.Cells[1, 10].Value = "Status";

        var employees = dbContext.Employees.ToList();
        for (int i = 0; i < employees.Count; i++)
        {
          var employee = employees[i];
          worksheet.Cells[i + 2, 1].Value = employee.Id;
          worksheet.Cells[i + 2, 2].Value = employee.Nom;
          worksheet.Cells[i + 2, 3].Value = employee.Email;
          worksheet.Cells[i + 2, 4].Value = employee.Datenaissance.ToString("yyyy-MM-dd");
          worksheet.Cells[i + 2, 5].Value = employee.Daterec.ToString("yyyy-MM-dd");
          worksheet.Cells[i + 2, 6].Value = employee.Username;
          worksheet.Cells[i + 2, 7].Value = employee.Password;
          worksheet.Cells[i + 2, 8].Value = employee.Adresse;
          worksheet.Cells[i + 2, 9].Value = employee.Poste;
          worksheet.Cells[i + 2, 10].Value = employee.Status ? "Active" : "Inactive";
        }

        worksheet.Cells.AutoFitColumns();

        return package.GetAsByteArray();
      }
    }

    public void ImportEmployeesFromExcel(byte[] excelFile)
    {
      using (MemoryStream memoryStream = new MemoryStream(excelFile))
      {
        using (ExcelPackage package = new ExcelPackage(memoryStream))
        {
          ExcelWorksheet worksheet = package.Workbook.Worksheets[0];

          int rowCount = worksheet.Dimension.Rows;

          List<Employee> employeesToImport = new List<Employee>();

          for (int row = 2; row <= rowCount; row++)
          {
            Employee employee = new Employee
            {
              Id = Guid.NewGuid(),
              Nom = worksheet.Cells[row, 2].Value?.ToString(),
              Email = worksheet.Cells[row, 3].Value?.ToString(),
              Datenaissance = DateTime.Parse(worksheet.Cells[row, 4].Value?.ToString()),
              Daterec = DateTime.Parse(worksheet.Cells[row, 5].Value?.ToString()),
              Username = worksheet.Cells[row, 6].Value?.ToString(),
              Password = worksheet.Cells[row, 7].Value?.ToString(),
              Adresse = worksheet.Cells[row, 8].Value?.ToString(),
              Poste = worksheet.Cells[row, 9].Value?.ToString(),
              Status = bool.Parse(worksheet.Cells[row, 10].Value?.ToString())
            };

            employeesToImport.Add(employee);
          }

          dbContext.Employees.AddRange(employeesToImport);
          dbContext.SaveChanges();
        }
      }
    }

    public async Task UpdatePasswordAsync(Guid employeeId, string newPassword)
    {
      var employee = await dbContext.Employees.FindAsync(employeeId);
      if (employee == null)
      {
        throw new ArgumentException("Employee not found");
      }

      employee.Password = newPassword;
      await dbContext.SaveChangesAsync();
    }

    public async Task AssignRoleToEmployee(Guid employeeId, Role newRole)
    {
      var employee = await dbContext.Employees.FindAsync(employeeId);
      if (employee == null)
      {
        throw new ArgumentException("Employee not found");
      }

      employee.Role = newRole;
      await dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<Employee>> GetEmployeesByTeam(Guid equipeId)
    {
      return await dbContext.Employees
                            .Where(e => e.EquipeId == equipeId)
                            .ToListAsync();
    }
  }
}
