using evaluationback.Models.Domain;
using evaluationback.Models.DTO;

namespace evaluationback.Services
{
  public interface IFieldResponseService
  {
    Task<List<FieldResponse>> GetFormResponsesByEmployeeAsync(Guid employeeId, Guid formulaireId);
    Task<bool> SubmitFormResponsesAsync(List<FieldResponseDto> fieldResponsesDto, Guid employeeId);
    Task<Guid> SaveFieldResponseAsync(FieldResponseDto fieldResponseDto);
    Task<List<FieldResponse>> GetResponsesByFieldIdAsync(Guid fieldId);
  }
}
