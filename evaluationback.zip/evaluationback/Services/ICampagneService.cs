using evaluationback.Models.Domain;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public interface ICampagneService
  {
    Task<Campagne> CreateCampagneAsync(Campagne campagne, Guid managerId, Guid? formulaireId = null);
    Task UpdateCampagneAsync(Guid campagneId, Campagne updatedCampagne);
    Task DeleteCampagneAsync(Guid campagneId);
    Task<string> GetCampagneStatusAsync(Guid campagneId);
    Task LaunchCampaignAsync(Guid campagneId);
    Task<Campagne?> GetCampagneByIdAsync(Guid campagneId);
    Task<List<Campagne>> GetAllCampagnesAsync();
    Task<List<Campagne>> GetAllCampagnesPaginatedAsync(int pageIndex, int pageSize);
    
  }
}
