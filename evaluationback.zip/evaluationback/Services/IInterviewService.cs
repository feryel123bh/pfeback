using evaluationback.Models.Domain;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public interface IInterviewService
  {
    Task ScheduleInterviewAsync(Guid campagneId, Guid managerId, List<Guid> employeeIds, DateTime interviewDate);
    Task CancelInterviewAsync(Guid interviewId);  // Assurez-vous que cette méthode est bien dans l'interface
    Task<IEnumerable<Interview>> GetInterviewsByEmployeeAsync(Guid employeeId);
  }
}
