using evaluationback.Models.Domain;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IEmployeeService
{
  Task<IEnumerable<Employee>> GetEmployeesByRoleAsync(Role role);
  Task<Employee> AddEmployee(Employee employee); // Reste inchangé, retourne une tâche qui contient un Employee
  Task<Employee> GetEmployeeById(Guid id); // Retourne une tâche qui contient un Employee
  Task<IEnumerable<Employee>> GetAllEmployeesAsync(); // Retourne une tâche qui contient une liste d'employés
  Task<IEnumerable<Employee>> GetAllManagersAsync(); // Retourne une tâche qui contient une liste de managers
  Task<Employee> UpdateEmployee(Guid id, Employee employee); // Retourne une tâche qui contient un Employee
  Task DeleteEmployee(Guid id); // Retourne une tâche (void asynchrone)
  byte[] ExportEmployeesToExcel(); // Pas de changement, retourne un tableau de bytes
  void ImportEmployeesFromExcel(byte[] excelFile); // Pas de changement, opération synchrone
  Task UpdatePasswordAsync(Guid employeeId, string newPassword); // Retourne une tâche (void asynchrone)
  Task AssignRoleToEmployee(Guid employeeId, Role newRole); // Retourne une tâche (void asynchrone)
  Task<IEnumerable<Employee>> GetEmployeesByTeam(Guid equipeId); // Retourne une tâche qui contient une liste d'employés
}
