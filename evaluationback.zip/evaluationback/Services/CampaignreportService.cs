using evaluationback.Data;
using evaluationback.Models.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class CampaignreportService : ICampaignreportService
  {
    private readonly Dbcontext _dbContext;

    public CampaignreportService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    public async Task CreateCampaignReportAsync(CampaignReport report)
    {
      _dbContext.CampaignReports.Add(report);
      await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateCampaignReportAsync(CampaignReport report)
    {
      _dbContext.CampaignReports.Update(report);
      await _dbContext.SaveChangesAsync();
    }

    public async Task<CampaignReport> GetCampaignReportByCampaignIdAsync(Guid campagneId)
    {
      var report = await _dbContext.CampaignReports.FirstOrDefaultAsync(cr => cr.CampagneId == campagneId);

      if (report == null)
      {
        throw new KeyNotFoundException($"Campaign report for campaign ID {campagneId} was not found.");
      }

      return report;
    }

  }
}
