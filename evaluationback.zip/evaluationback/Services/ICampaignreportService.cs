using evaluationback.Models.Domain;

namespace evaluationback.Services
{
  public interface ICampaignreportService
  {
    Task CreateCampaignReportAsync(CampaignReport report);
    Task UpdateCampaignReportAsync(CampaignReport report);
    Task<CampaignReport> GetCampaignReportByCampaignIdAsync(Guid campagneId);

  }
}
