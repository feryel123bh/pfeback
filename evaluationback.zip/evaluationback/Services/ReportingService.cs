using evaluationback.Data;
using evaluationback.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace evaluationback.Services
{
  public class ReportingService
  {
    private readonly Dbcontext _dbContext;

    public ReportingService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    // Générer un rapport de campagne

  }

 
 
}
