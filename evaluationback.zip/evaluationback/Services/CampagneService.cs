using evaluationback.Data;
using evaluationback.Models.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class CampagneService : ICampagneService
  {
    private readonly Dbcontext _dbContext;
    private readonly NotificationService _notificationService;
    private readonly EmailService _emailService;
    private readonly ICampaignreportService _campaignreportService;
    private readonly IMemoryCache _cache;

    public CampagneService(Dbcontext dbContext, NotificationService notificationService, EmailService emailService, ICampaignreportService campaignreportService, IMemoryCache cache)
    {
      _dbContext = dbContext;
      _notificationService = notificationService;
      _emailService = emailService;
      _campaignreportService = campaignreportService;
      _cache = cache;
    }

    public async Task<Campagne> CreateCampagneAsync(Campagne campagne, Guid managerId, Guid? formulaireId = null)
    {
      campagne.Id = Guid.NewGuid();
      campagne.Status = Status.Aréaliser;

      // Assign manager
      var manager = await _dbContext.Employees.FindAsync(managerId);
      if (manager == null)
      {
        throw new ArgumentException("Manager not found");
      }
      campagne.Manager = manager;

      // Assign form if provided
      if (formulaireId.HasValue)
      {
        var formulaire = await _dbContext.Formulaires.FindAsync(formulaireId.Value);
        if (formulaire != null)
        {
          campagne.Formulaire = formulaire;
        }
      }

      _dbContext.Campagnes.Add(campagne);
      await _dbContext.SaveChangesAsync();

      // Create an initial campaign report
      var campaignReport = new CampaignReport
      {
        CampagneId = campagne.Id,
        Titre = campagne.Titre,
        DateDebut = campagne.StartDate,
        DateFin = campagne.EndDate,
        TotalEmployees = campagne.Equipes.Sum(e => e.Employees.Count),
        CompletedEvaluations = 0,
        PendingEvaluations = campagne.Equipes.Sum(e => e.Employees.Count),
        AverageScore = 0,
        Comments = new List<string>()
      };

      await _campaignreportService.CreateCampaignReportAsync(campaignReport);

      _cache.Remove("all_campagnes");

      return campagne;
    }

    public async Task LaunchCampaignAsync(Guid campagneId)
    {
      var campagne = await _dbContext.Campagnes
          .Include(c => c.Equipes)
          .ThenInclude(e => e.Employees)
          .FirstOrDefaultAsync(c => c.Id == campagneId);

      if (campagne == null)
      {
        throw new ArgumentException("Campaign not found.");
      }

      if (campagne.Status == Status.Encours)
      {
        throw new InvalidOperationException("The campaign is already launched.");
      }

      foreach (var equipe in campagne.Equipes)
      {
        foreach (var employee in equipe.Employees)
        {
          if (!string.IsNullOrEmpty(employee.Email))
          {
            // Send notification
            await _notificationService.SendNotificationAsync(employee.Email,
                "New Evaluation Campaign",
                $"You have been assigned to a new evaluation campaign: {campagne.Titre}.");

            // Send email with the link to the form
            var formUrl = $"https://yourapp.com/campaigns/{campagne.Id}/forms/{campagne.FormulaireId}";
            await _emailService.SendNotificationAsync(employee.Email,
                "New Evaluation Campaign",
                $"You have been assigned to a new evaluation campaign: {campagne.Titre}. " +
                $"Please complete the following form: <a href='{formUrl}'>Click here to complete the form</a>");
          }
          else
          {
            // Log or handle cases where email is null or empty
            Console.WriteLine($"Employee {employee.Nom} {employee.Prenom} does not have a valid email address.");
          }
        }
      }

      campagne.Status =Status.Encours;
      await _dbContext.SaveChangesAsync();

      // Update campaign report to reflect launch
      var report = await _campaignreportService.GetCampaignReportByCampaignIdAsync(campagneId);
      if (report != null)
      {
        report.DateDebut = campagne.StartDate;
        report.DateFin = campagne.EndDate;
        await _campaignreportService.UpdateCampaignReportAsync(report);
      }

      _cache.Remove($"campagne_{campagneId}");
    }


    public async Task UpdateCampagneAsync(Guid campagneId, Campagne updatedCampagne)
    {
      var existingCampagne = await _dbContext.Campagnes
          .Include(c => c.Formulaire)
          .FirstOrDefaultAsync(c => c.Id == campagneId);

      if (existingCampagne == null)
      {
        throw new ArgumentException("Campagne not found");
      }

      existingCampagne.Titre = updatedCampagne.Titre;
      existingCampagne.Description = updatedCampagne.Description;
      existingCampagne.CampaignType = updatedCampagne.CampaignType;
      existingCampagne.StartDate = updatedCampagne.StartDate;

      if (updatedCampagne.Formulaire != null)
      {
        existingCampagne.Formulaire = updatedCampagne.Formulaire;
      }

      _dbContext.Campagnes.Update(existingCampagne);
      await _dbContext.SaveChangesAsync();

      _cache.Remove($"campagne_{campagneId}");
    }

    public async Task DeleteCampagneAsync(Guid campagneId)
    {
      var campagne = await _dbContext.Campagnes.FindAsync(campagneId);
      if (campagne == null)
      {
        throw new ArgumentException("Campagne not found");
      }

      _dbContext.Campagnes.Remove(campagne);
      await _dbContext.SaveChangesAsync();

      _cache.Remove($"campagne_{campagneId}");
    }

    public async Task<string> GetCampagneStatusAsync(Guid campagneId)
    {
      var campagne = await _dbContext.Campagnes.FindAsync(campagneId);
      if (campagne == null)
      {
        throw new ArgumentException("Campagne not found");
      }

      if (campagne.StartDate > DateTime.UtcNow)
            {
        return "Not Started";
      }
      else if (campagne.Status ==Status.Encours)
      {
        return "In Progress";
      }
      else
      {
        return "Completed";
      }
    }



    public async Task<Campagne?> GetCampagneByIdAsync(Guid campagneId)
    {
      return await _cache.GetOrCreateAsync($"campagne_{campagneId}", async entry =>
      {
        entry.SlidingExpiration = TimeSpan.FromMinutes(5);
        return await _dbContext.Campagnes
                               .Include(c => c.Formulaire)
                               .Include(c => c.Equipes)
                               .ThenInclude(e => e.Employees)
                               .FirstOrDefaultAsync(c => c.Id == campagneId);
      });
    }
    public async Task<List<Campagne>> GetAllCampagnesAsync()
    {
      return await _dbContext.Campagnes
                             .Include(c => c.Formulaire)
                             .Include(c => c.Manager)
                             .Include(c => c.NotifiedEmployees)
                             .Include(c => c.Equipes)
                             .ThenInclude(e => e.Employees)
                             .ToListAsync();
    }

    public async Task<List<Campagne>> GetAllCampagnesPaginatedAsync(int pageIndex, int pageSize)
    {
      return await _dbContext.Campagnes
                             .Include(c => c.Formulaire)
                             .Include(c => c.Equipes)
                             .ThenInclude(e => e.Employees)
                             .Skip((pageIndex - 1) * pageSize)
                             .Take(pageSize)
                             .ToListAsync();
    }
  }
}
