using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using evaluationback.Data;

namespace evaluationback.Services
{
  public class AuthenticationService
  {
    private readonly IConfiguration _configuration;
    private readonly Dbcontext _dbContext;

    public AuthenticationService(IConfiguration configuration, Dbcontext dbContext)
    {
      _dbContext = dbContext;
      _configuration = configuration;
    }

    public async Task<string?> AuthenticateAsync(LoginRequest request)
    {
      var user = await ValidateUserAsync(request.Username, request.Password);

      if (user == null)
      {
        return null;
      }

      var tokenHandler = new JwtSecurityTokenHandler();
      var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
      var tokenDescriptor = new SecurityTokenDescriptor
      {
        Subject = new ClaimsIdentity(new[]
          {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role.ToString())
        }),
        Expires = DateTime.UtcNow.AddDays(7),
        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
      };
      var token = tokenHandler.CreateToken(tokenDescriptor);
      return tokenHandler.WriteToken(token);
    }


    private async Task<Employee?> ValidateUserAsync(string username, string password)
    {
      var hashedPassword = ComputeSha256Hash(password);
      return await _dbContext.Employees.FirstOrDefaultAsync(e => e.Username == username && e.Password == hashedPassword);
    }

    private string ComputeSha256Hash(string rawData)
    {
      using (var sha256Hash = System.Security.Cryptography.SHA256.Create())
      {
        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < bytes.Length; i++)
        {
          builder.Append(bytes[i].ToString("x2"));
        }
        return builder.ToString();
      }
    }
  }

}
