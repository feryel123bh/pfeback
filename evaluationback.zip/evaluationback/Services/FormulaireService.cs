using evaluationback.Data;
using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class FormulaireService : IFormulaireService
  {
    private readonly Dbcontext _dbContext;

    public FormulaireService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    public async Task<Guid> SaveFormulaireAsync(FormulaireDto formulaireDto)
    {
      try
      {
        var formulaire = new Formulaire
        {
          Title = formulaireDto.Title,
          DateCreated = DateTime.UtcNow,
          Sections = formulaireDto.Sections.Select(s => new Section
          {
            Title = s.Title,
            Order = s.Order,
            Fields = s.Fields.Select(f => new Field
            {
              FieldType = f.FieldType,
              Label = f.Label,
              Placeholder = f.Placeholder,
              IsRequired = f.IsRequired,
              Span = f.Span,
              IsHelpBlockVisible = f.IsHelpBlockVisible,
              HelpBlockText = f.HelpBlockText,
              OptionsJson = f.Options != null ? JsonConvert.SerializeObject(f.Options) : null
            }).ToList()
          }).ToList()
        };

        _dbContext.Formulaires.Add(formulaire);
        await _dbContext.SaveChangesAsync();

        return formulaire.Id;
      }
      catch (Exception ex)
      {
        // Log the exception
        Console.WriteLine($"Error saving formulaire: {ex.Message}");
        throw; // Rethrow or handle it as needed
      }
    }

    public async Task DeleteFormulaireAsync(Guid id)
    {
      var formulaire = await _dbContext.Formulaires.FindAsync(id);
      if (formulaire == null)
      {
        throw new KeyNotFoundException("Formulaire not found.");
      }

      _dbContext.Formulaires.Remove(formulaire);
      await _dbContext.SaveChangesAsync();
    }

    public async Task<Formulaire> GetFormulaireByIdAsync(Guid id)
    {
      var formulaire = await _dbContext.Formulaires
          .Include(f => f.Sections)
          .ThenInclude(s => s.Fields)
          .FirstOrDefaultAsync(f => f.Id == id);

      if (formulaire == null)
      {
        // Handle the null case, e.g., throw an exception or return null
        throw new KeyNotFoundException("Formulaire not found.");
      }

      return formulaire;
    }
    public async Task UpdateFormulaireAsync(Guid id, FormulaireDto formulaireDto)
    {
      var formulaire = await _dbContext.Formulaires
          .Include(f => f.Sections)
          .ThenInclude(s => s.Fields)
          .FirstOrDefaultAsync(f => f.Id == id);

      if (formulaire == null)
      {
        throw new KeyNotFoundException("Formulaire not found.");
      }

      // Update the properties of the Formulaire
      formulaire.Title = formulaireDto.Title;

      // Optionally update other properties, for example, Sections and Fields
      // This example assumes complete replacement, but you can customize it as needed.
      formulaire.Sections = formulaireDto.Sections.Select(s => new Section
      {
        Title = s.Title,
        Order = s.Order,
        Fields = s.Fields.Select(f => new Field
        {
          FieldType = f.FieldType,
          Label = f.Label,
          Placeholder = f.Placeholder,
          IsRequired = f.IsRequired,
          Span = f.Span,
          IsHelpBlockVisible = f.IsHelpBlockVisible,
          HelpBlockText = f.HelpBlockText,
          OptionsJson = f.Options != null ? JsonConvert.SerializeObject(f.Options) : null
        }).ToList()
      }).ToList();

      _dbContext.Formulaires.Update(formulaire);
      await _dbContext.SaveChangesAsync();
    }

    public async Task<List<Formulaire>> GetAllFormulairesAsync()
    {
      return await _dbContext.Formulaires
          .Include(f => f.Sections)
          .ThenInclude(s => s.Fields)
          .ToListAsync();
    }
  }
}
