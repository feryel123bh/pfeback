using evaluationback.Models.Domain;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public interface IEvaluationService
  {
    Task<Evaluation> CreateEvaluationAsync(Evaluation evaluation);
    Task<Evaluation> RecordInterviewResultsAsync(Guid interviewId, Guid employeeId, string comments, int score);
    //Task<List<Evaluation>> GetEvaluationsByCampaignAsync(Guid campagneId);
    Task<Evaluation> GetEvaluationByIdAsync(Guid evaluationId);
    Task<Evaluation> UpdateEvaluationAsync(Evaluation updatedEvaluation);
    Task DeleteEvaluationAsync(Guid evaluationId);
    Task<List<Evaluation>> GetAllEvaluationsAsync();
  }
}
