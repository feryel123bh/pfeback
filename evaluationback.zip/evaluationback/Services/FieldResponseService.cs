using evaluationback.Data;
using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace evaluationback.Services
{
  public class FieldResponseService : IFieldResponseService
  {
    private readonly Dbcontext _dbContext;

    public FieldResponseService(Dbcontext dbContext)
    {
      _dbContext = dbContext;
    }

    public async Task<Guid> SaveFieldResponseAsync(FieldResponseDto fieldResponseDto)
    {
      var responseValue = JsonConvert.SerializeObject(new
      {
        type = fieldResponseDto.ResponseType,
        value = fieldResponseDto.ResponseValue
      });

      var fieldResponse = new FieldResponse
      {
        FieldId = fieldResponseDto.FieldId,
        EmployeeId = fieldResponseDto.EmployeeId,
        ResponseValue = responseValue,
        DateSubmitted = DateTime.UtcNow
      };

         _dbContext.FieldResponses.Add(fieldResponse);
      await _dbContext.SaveChangesAsync();

      return fieldResponse.Id;
    }

    public async Task<List<FieldResponse>> GetResponsesByFieldIdAsync(Guid fieldId)
    {
      return await _dbContext.FieldResponses
                             .Where(fr => fr.FieldId == fieldId)
                             .Include(fr => fr.Employee)
                             .ToListAsync();
    }
    public async Task<List<FieldResponse>> GetFormResponsesByEmployeeAsync(Guid employeeId, Guid formulaireId)
    {
      var formFields = await _dbContext.Fields
                                        .Where(f => f.Section.FormulaireId == formulaireId)
                                        .Select(f => f.Id)
                                        .ToListAsync();

      return await _dbContext.FieldResponses
                             .Where(fr => fr.EmployeeId == employeeId && formFields.Contains(fr.FieldId))
                             .Include(fr => fr.Field)
                             .ToListAsync();
    }
    public async Task<bool> SubmitFormResponsesAsync(List<FieldResponseDto> fieldResponsesDto, Guid employeeId)
    {
      var fieldResponses = new List<FieldResponse>();

      foreach (var fieldResponseDto in fieldResponsesDto)
      {
        var responseValue = JsonConvert.SerializeObject(new
        {
          type = fieldResponseDto.ResponseType,
          value = fieldResponseDto.ResponseValue
        });

        var fieldResponse = new FieldResponse
        {
          FieldId = fieldResponseDto.FieldId,
          EmployeeId = employeeId,
          ResponseValue = responseValue,
          DateSubmitted = DateTime.UtcNow
        };

        fieldResponses.Add(fieldResponse);
      }

      _dbContext.FieldResponses.AddRange(fieldResponses);
      await _dbContext.SaveChangesAsync();

      return true;  // Indicate that the form was successfully submitted
    }


  }

}
