using evaluationback.Models.Domain;
using evaluationback.Models.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IEquipeService
{
  Task<Equipe> AddEquipeAsync(EquipeDto equipeDto);
  Task<Equipe> GetEquipeByIdAsync(Guid id);
  Task<IEnumerable<Equipe>> GetAllEquipesAsync();
  Task<Equipe> UpdateEquipeAsync(Guid id, EquipeDto equipeDto);
  Task DeleteEquipeAsync(Guid id);
  Task AddEmployeeToEquipeAsync(Guid equipeId, Guid employeeId);
  Task RemoveEmployeeFromEquipeAsync(Guid equipeId, Guid employeeId);
  Task<IEnumerable<Employee>> GetEmployeesInEquipeAsync(Guid equipeId);
  Task AssignManagerToEquipeAsync(Guid equipeId, Guid managerId);
  byte[] ExportEquipesToExcel();
}
